# DD4AV: Detecting Atomicity Violations in Interrupt-Driven Programs with Guided Concolic Execution and Filtering

DD4AV is a dynamically controlled scheduling testing tool that explores possible interleavings of interrupt-driven programs to detect atomicity violations. 

This repository provides the tool and evaluation subjects for the paper "DD4AV: Detecting Atomicity Violations in Interrupt-Driven Programs with Guided Concolic Execution and Filtering."

**Table of contents**
- [Directory Structure](#directory-structure)
- [Tool](#tool)
  - [Requirements](#requirements)
  - [Installation](#installation)
- [Quick Start for Simple Test](#quick-start-for-simple-test)
- [Quick Start for Reproducing the Experimental Results](#quick-start-for-reproducing-the-experimental-results)
----------


## Directory Structure

The repository mainly contains three folders: [*tool*](#tool) , [*test*](#test) [*Racebench_2.1*](#Racebench_2.1) and [*realworld_AV*](#realworld_av). We briefly introduce each folder under `/yourworkdir/DD4AV`: 
- `clang+llvm`: Pre-Built Binaries of LLVM 10.0. These binaries include Clang, LLD, compiler-rt, various LLVM tools, etc.
- `tools`: The root directory containing DD4AV's tools and scripts.
  - `DBDS`: Code implementing a dynamic scheduling execution method that systematically explores task interleavings to detect atomicity violations, leveraging guided concolic execution and filtering with a prefix-directed strategy for enhanced efficiency.
  - `staticAnalysis`: Scripts for static analysis that identify key operations for scheduling during testing and obtain read/write access counts required for filtering.
  - `SVF`: The third-party library project provides interprocedural dependence analysis for LLVM-based languages. SVF can perform pointer alias analysis, memory SSA form construction, and value-flow tracking for program variables.
  - `wllvm`: The third-party library project provides tools for building whole-program or whole-library LLVM bitcode files from unmodified C or C++ source packages.
- `test`: Simple example programs designed for easy understanding and verification of the tool's installation.
- `Racebench_2.1`: A benchmark of programs covering diverse program logic and data structures, ranging from simple to complex, with manually constructed atomicity violation scenarios for evaluation.
- `realworld_AV`: 18 real-world embedded interrupt-driven programs, all written in C, including control software, firmware, and device drivers.
----------

## Tool

### Requirements
To install the tool from source code on your host system, please ensure that your environment meets the following requirements:

- **Operating System:** Ubuntu 18.04 LTS or higher (requires kernel version 4.x or above due to the scheduling policy).


### Installation
- **install Dependencies:** Our artifact depends on several packages, please run the following command to install all necessary dependencies.

  ```bash
  sudo apt-get install -y wget git build-essential python3 python python-pip python3-pip tmux cmake libtool libtool-bin automake autoconf autotools-dev m4 autopoint libboost-dev help2man gnulib bison flex texinfo zlib1g-dev libexpat1-dev libfreetype6 libfreetype6-dev libbz2-dev liblzo2-dev libtinfo-dev libssl-dev pkg-config libswscale-dev libarchive-dev liblzma-dev liblz4-dev doxygen libncurses5 vim intltool gcc-multilib sudo --fix-missing
  ```
  
  ```bash
  pip install numpy && pip3 install numpy && pip3 install sysv_ipc
  ```
- **Download the Code**

    Download DD4AV from the Figshare website to your local machine and navigate to the project directory:
    ```bash
    cd DD4AV
    ```

- **Configure the environment and install the tool.**

    For convenience, we provide shell scripts to automate the installation process. Run the following commands to configure the environment and install the necessary tools:
    
    ```bash
    # Install LLVM and clang
    tool/install_llvm.sh

    # Set up the environment
    source tool/init_env.sh

    # Install SVF
    $ROOT_DIR/tool/install_SVF.sh

    # Install static analysis tool
    $ROOT_DIR/tool/install_staticAnalysis.sh

    # Install wllvm
    sudo pip install -e $ROOT_DIR/tool/wllvm/
    ```

- **Usage**
	
	Each time you open a new terminal, you will need to set the environment variables to ensure proper execution of the tool:

	```bash
	# set up environment
    source tool/init_env.sh
	```

----------

## Quick Start for Simple Test

Before using DD4AV, we recommend starting with the simple examples provided to ensure that the tool functions correctly. Below, we use the `simple_test` example in the `test` folder to demonstrate how to use DD4AV.

- **Navigate to the working directory:**

    ```bash
    cd $ROOT_DIR/test/simple_test
    ```

- **Build the program using the provided scripts:**

   ```bash
   ./clean.sh && ./build.sh
   ```

- **Perform systematic controlled testing with periodical scheduling:**

    ```bash
    $ROOT_DIR/tool/DBDS/run.py -y -d 4 ./simple_test
    ```
    When the number of tasks is 𝑛, the maximum preemption count is set to 2𝑛−2(specified by the `-d` parameter).


- **Expected output:**

  If DD4AV operates correctly, you should see an output similar to the following, indicating that DD4AV detected 1 atomicity violation in the program:
  ```bash
  Start Testing!
  There is no schedule to satisfy under the constraint: [2, 1, 1] ,  2
  Targeting bugs that bug depth = 1 . Iterate for 2 periods
  Targeting bugs that bug depth = 2 . Iterate for 3 periods
  test 0001: [[0, 0], [1], [2]]
  test 0002: [[0, 0], [2], [1]]
  test 0003: [[1], [0, 0], [2]]
  test 0004: [[1], [2], [0, 0]]
  test 0005: [[2], [0, 0], [1]]
  test 0006: [[2], [1], [0, 0]]
  Targeting bugs that bug depth = 3 . Iterate for 4 periods
  test 0007: [[0], [1], [0], [2]]
  test 0008: [[0], [1], [2], [0]]
  test 0009: [[0], [2], [0], [1]]
  test 0010: [[0], [2], [1], [0]]
  test 0011: [[1], [0], [2], [0]]
  test 0012: [[2], [0], [1], [0]]
  There is no schedule to satisfy under the constraint in stage 2: [2, 1, 1] ,  4
  There is no schedule to satisfy under the constraint in stage 2: [2, 1, 1] ,  4
  There is no schedule to satisfy under the constraint: [2, 1, 1] ,  5
  Targeting bugs that bug depth = 4 . Iterate for 5 periods
  test 0013 for prefix [[0], [1]]: [[0], [1], [2, 2], [1], [0]]
  There is no schedule to satisfy under the constraint in stage 2: [2, 1, 1] ,  5
  End Testing!
  
  
  --------------------------------------------------
  (1) (('W', 13), ('R', 22), ('W', 16))
  Total Round: 13
  First_buggy_round:7     Total_buggy_rounds:4    Total_rounds:13
  Time:00.18557
  ```
- **Success**    
If you successfully execute the above steps, your installation is complete! You can now explore other examples in the `test` folder or proceed with reproducing our experimental results.


## Quick Start for Reproducing the Experimental Results

- **Experiment for DD4AV on Racebench_2.1**

    ```bash
    $ cd $ROOT_DIR/Racebench_2.1
    $ ./runAll.sh 
    ```
  
  The outcomes of 10 executions for detecting atomicity violations will be saved in `output.csv` within each test program's directory.
    
  ```text
  # Example(svp_simple_001/output.csv):
  Run,DynamicExecutionTime,bug_depth,firstAVSched,AVSched,totalSched,AV_num,AV_Details
  1,26.87885,4,107,11,1204,2,"(1) ((W, 16), (R, 36), (W, 21)) (2) ((W, 29), (R, 39), (W, 30))"
  2,27.08464,4,107,11,1204,2,"(1) ((W, 16), (R, 36), (W, 21)) (2) ((W, 29), (R, 39), (W, 30))"
  3,26.72797,4,107,11,1204,2,"(1) ((W, 29), (R, 39), (W, 30)) (2) ((W, 16), (R, 36), (W, 21))"
  ...

  ```
  Full results are saved in each program’s `output.csv`.

  For a comprehensive overview and direct access to the average results of all test programs, refer to the automatically generated table in `Racebench_2.1/summary_output.csv`, assuming all tests in `Racebench_2.1` are successfully executed.

- **Experiment for DD4AV on realworld_AV**

    ```bash
    $ cd $ROOT_DIR/realworld_AV
    $ ./runAll.sh 
    ```
  
  The outcomes of 10 executions for detecting atomicity violations will be saved in `output.csv` within each test program's directory.
    
  ```text
  # Example(blink1/output.csv):
  Run,DynamicExecutionTime,bug_depth,AVSched,totalSched,AV_num,AV_Details
  1,01.16137,4,40,52,10,"(1) ((R, 57), (W, 79), (R, 60)) (2) ((W, 42), (W, 64), (R, 43)) (3) ((W, 42), (W, 79), (R, 43)) (4) ((R, 60), (W, 79), (W, 64)) (5) ((W, 42), (W, 74), (R, 43)) (6) ((R, 60), (W, 74), (W, 64)) (7) ((R, 38), (W, 79), (W, 42)) (8) ((R, 38), (W, 64), (W, 42)) (9) ((R, 38), (W, 74), (W, 42)) (10) ((R, 57), (W, 74), (R, 60))"
  2,01.16925,4,40,52,10,"(1) ((R, 60), (W, 79), (W, 64)) (2) ((W, 42), (W, 64), (R, 43)) (3) ((R, 38), (W, 79), (W, 42)) (4) ((R, 57), (W, 79), (R, 60)) (5) ((R, 38), (W, 74), (W, 42)) (6) ((R, 57), (W, 74), (R, 60)) (7) ((R, 38), (W, 64), (W, 42)) (8) ((W, 42), (W, 79), (R, 43)) (9) ((R, 60), (W, 74), (W, 64)) (10) ((W, 42), (W, 74), (R, 43))"
  3,01.28141,4,40,52,10,"(1) ((R, 38), (W, 74), (W, 42)) (2) ((R, 60), (W, 79), (W, 64)) (3) ((R, 38), (W, 64), (W, 42)) (4) ((W, 42), (W, 64), (R, 43)) (5) ((R, 38), (W, 79), (W, 42)) (6) ((R, 57), (W, 79), (R, 60)) (7) ((W, 42), (W, 74), (R, 43)) (8) ((R, 57), (W, 74), (R, 60)) (9) ((R, 60), (W, 74), (W, 64)) (10) ((W, 42), (W, 79), (R, 43))"
  ...
  ```
  Full results are saved in each program’s `output.csv`.

  For a comprehensive overview and direct access to the average results of all test programs, refer to the automatically generated table in `realworld_AV/summary_output.csv`, assuming all tests in `realworld_AV` are successfully executed.
  

