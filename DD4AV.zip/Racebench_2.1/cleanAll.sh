#!/bin/bash


# Enter the destination folder
cd "$ROOT_DIR/Racebench_2.1"
rm -rf ./*.csv

# Traverse the subfolders
for folder in */; do
  if [ -d "$folder" ]; then
    echo "Processing folder: $folder"
    cd "$folder"

    # Enter the Tests subfolder
    cd "$ROOT_DIR/Racebench_2.1/$folder"

    # Execute build.sh and cleanDIR.sh
    ./clean.sh
#    rm execution_log.txt

    # Return to parent directory
    cd ..
  fi
done

