rm -rf ./out_*
rm -rf ./*_out_*
rm -rf ./analysis_output*