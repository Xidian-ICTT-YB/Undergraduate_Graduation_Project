#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <pthread.h>
#include <assert.h>

volatile int svp_simple_001_001_global_var;
volatile int svp_simple_001_001_global_array[100];
volatile int svp_simple_001_001_global_flag = 0;
#define MAX_LENGTH 100
#define TRIGGER 99

void task_main() {
  for (int i = 0; i < MAX_LENGTH; i++) {
    svp_simple_001_001_global_array[i] = 0;
  }

  for (int i = 0; i < MAX_LENGTH; i++) {
    if (i == TRIGGER) {
        svp_simple_001_001_global_array[i] = 1;
    }
  }
}

void isr1() {
  svp_simple_001_001_global_flag = 1;

  svp_simple_001_001_global_var = 0;
  svp_simple_001_001_global_var = 1;
}

void isr2() {
  int reader1;
  if (svp_simple_001_001_global_flag == 1)
    reader1 = svp_simple_001_001_global_array[TRIGGER];

  int reader2;
  reader2 = svp_simple_001_001_global_var;
}

void isr3(){}

int main(int argc, char **argv) {
    return 0;
}
