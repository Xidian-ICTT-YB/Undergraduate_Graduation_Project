#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <pthread.h>
#include <assert.h>


#define MAX_LENGTH 100
#define TRIGGER 99

volatile int svp_simple_002_001_global_array[MAX_LENGTH];
volatile int casee2_global_var;

void task_main() {
      int a = 0;
}

void isr1() {
    int mininum, maxnum;
    for (int i = 0; i < MAX_LENGTH; i++) {
        if (i == TRIGGER) 
        {
            svp_simple_002_001_global_array[TRIGGER] = 1;
        }
        if (i == MAX_LENGTH + 1)
        {
            svp_simple_002_001_global_array[TRIGGER] = 1;
        }
    }
    mininum = svp_simple_002_001_global_array[TRIGGER] - 10;

}

void isr2() {
    svp_simple_002_001_global_array[TRIGGER] = 999;
}

void isr3(){}

int main(int argc, char **argv) {

    return 0;
}

