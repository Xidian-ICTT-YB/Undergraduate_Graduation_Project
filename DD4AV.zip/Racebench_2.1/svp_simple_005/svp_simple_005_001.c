#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <pthread.h>
#include <assert.h>

#define MAX_LENGTH 100
#define TRIGGER 99
#define TRIGGER1 10

volatile int svp_simple_005_001_global_condition = 0;

volatile int svp_simple_005_001_global_var;

void task_main() {
  for (int i = 0; i < MAX_LENGTH; i++) {
    for (int j = 0; j < MAX_LENGTH; j++) {
      if ((i == TRIGGER) && (j == TRIGGER1))
        svp_simple_005_001_global_var = 0x01;
    }
  }

  if (svp_simple_005_001_global_condition == 1) {
    svp_simple_005_001_global_var = 0x09;
  }

  svp_simple_005_001_global_var = 0x05;
}

void isr1() {
  int reader;
  reader = svp_simple_005_001_global_var;
}

void isr2(){}

void isr3(){}

int main(int argc, char **argv) {
    return 0;
}


