#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <pthread.h>
#include <assert.h>

#define MAX_LENGTH 50
#define TRIGGER49

volatile int svp_simple_006_001_global_var1;
volatile int svp_simple_006_001_global_var2;
volatile unsigned char flag = 0x55;
void task_main() {
  int reader1, reader2;
  
  for (int i = 0; i < MAX_LENGTH; i++) {
      for (int j = 0; j < MAX_LENGTH; j++) {
        if (i == j) {
          if (i == 0) {
            reader1 = svp_simple_006_001_global_var1;
          }
          else if (i == 3) {
            reader2 = svp_simple_006_001_global_var1;
          }
          else if (i == MAX_LENGTH + 1) {
            reader2 = svp_simple_006_001_global_var1;
          }
        }
      }
  }

  for (int i = 0; i < 4; i++) {
      for (int j = 0; j < 4; j++) {
        if (((i + j) == 6) && (i < j)) {
            svp_simple_006_001_global_var2 = 0x02;
        }
      }
  }
}

void isr1() {
  int reader2;
  svp_simple_006_001_global_var1 = 0;
  reader2 = svp_simple_006_001_global_var2;
}

void isr2(){}
void isr3(){}

int main(int argc, char **argv) {

    return 0;
}


