#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <pthread.h>
#include <assert.h>

#define MAX_LENGTH 100
#define TRIGGER 99

volatile int svp_simple_007_001_global_var=0;

volatile int svp_simple_007_001_global_array[5];

void task_main() {

  int reader1;

  svp_simple_007_001_global_array[svp_simple_007_001_global_var] = 0x01;

  // int i = rand();
  int i = 2;
  if (i == 2)
  {
    svp_simple_007_001_global_array[i] = 0x02;
  }
  else
  {
    svp_simple_007_001_global_array[i] = 0x09;
  }

  reader1 = svp_simple_007_001_global_array[2];
}

void isr1() {
  svp_simple_007_001_global_array[2] = 0x09;
  int tmp = svp_simple_007_001_global_var + 1;
  svp_simple_007_001_global_var = tmp;
  svp_simple_007_001_global_array[svp_simple_007_001_global_var] = 0x09;
}

void isr2(){}

void isr3(){}


int main(int argc, char **argv) {

    return 0;
}


