#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <pthread.h>
#include <assert.h>

#define MAX_LENGTH 100
#define TRIGGER 99

volatile int svp_simple_008_001_global_var;

volatile int svp_simple_008_001_global_array[10];

void task_main() {
  int p = 1;
  int q = 2;
  svp_simple_008_001_global_array[p + q] = 0x09;

  svp_simple_008_001_global_array[4] = 0x01;

  int reader1;
  int i = 1;
  int j = 2;
  p = 1;
  q = 3;
  reader1 = svp_simple_008_001_global_array[i * 2 + j * 1];
}

void isr1() {
  for (int k = 0; k < 10; k++) {
    svp_simple_008_001_global_array[k] = 0x05;
  }
}

void isr2(){}
void isr3(){}

int main(int argc, char **argv) {


    return 0;
}

// TP
// svp_simple_008_001_global_array[4]:(W20,W33,R27)

// FP
// not the same value: svp_simple_008_001_global_array[4]:(W18,W33,R28)  svp_simple_008_001_global_array[3]/arr[4]/arr[4]

