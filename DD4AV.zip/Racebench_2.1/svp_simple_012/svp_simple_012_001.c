#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <pthread.h>
#include <assert.h>

int svp_simple_012_001_global_var;

void task_main() {

  int *p;
  p = &svp_simple_012_001_global_var;
  svp_simple_012_001_global_var = 0x01;
  *p = 0x02;
}

void isr1() {
  int reader1;
  reader1 = svp_simple_012_001_global_var;
}

void isr2(){}
void isr3(){}

int main(int argc, char **argv) {

    return 0;
}

