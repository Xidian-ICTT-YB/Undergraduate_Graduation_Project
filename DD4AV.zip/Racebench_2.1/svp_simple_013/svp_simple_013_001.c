#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <pthread.h>
#include <assert.h>

#define MAX_LENGTH 100
#define TRIGGER 99

volatile int svp_simple_013_001_global_var1;
volatile int svp_simple_013_001_global_var2;

int svp_simple_013_001_global_flag1 = 0;
int svp_simple_013_001_global_flag2 = 1;

void task_main() {

  int reader1, reader2;
  int reader3, reader4;

  for (int i = 0; i < MAX_LENGTH; i++) {
      if (i == TRIGGER) {
        reader1 = svp_simple_013_001_global_var1;
      }
  }

  reader2 = svp_simple_013_001_global_var1;

  reader3 = svp_simple_013_001_global_var2;

  reader4 = svp_simple_013_001_global_var2;
}

void isr1(){}

void isr2() {
  svp_simple_013_001_global_flag1 = 1;
  svp_simple_013_001_global_flag2 = 0;
}

void isr3() {
  if (svp_simple_013_001_global_flag1 == 1) {
    svp_simple_013_001_global_var1 = 0x01;
  }
  if (svp_simple_013_001_global_flag2 == 1) {
    svp_simple_013_001_global_var2 = 0x01;
  }
}

int main(int argc, char **argv) {

    return 0;
}

