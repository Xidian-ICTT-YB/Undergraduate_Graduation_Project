#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <pthread.h>
#include <assert.h>

volatile int svp_simple_015_001_global_var1;
volatile int svp_simple_015_001_global_var2;

void task_main() {

//  int x = rand();
//  int y = rand();
//  int z;
//  int p = rand();
  int x = 4;
  int y = 2;
  int z;
  int p = 1;

  if ((svp_simple_015_001_global_var1 < y) &&
      (svp_simple_015_001_global_var1 > x)) {
      z = x + y;
  }

  p == 1 ? svp_simple_015_001_global_var2 : svp_simple_015_001_global_var2;
}

void isr1() {
  svp_simple_015_001_global_var1 = 5;
  svp_simple_015_001_global_var2 = 5;
}

void isr2(){}
void isr3(){}

int main(int argc, char **argv) {

    return 0;
}



