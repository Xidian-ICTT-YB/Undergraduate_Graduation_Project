#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <pthread.h>
#include <assert.h>

volatile int svp_simple_016_001_global_var1;

void task_main() {
    int reader1;
    svp_simple_016_001_global_var1 = 0x01;
    int tmp1 = svp_simple_016_001_global_var1;
    int tmp2 = svp_simple_016_001_global_var1 + tmp1;
    reader1 = svp_simple_016_001_global_var1 + tmp2;

}

void isr1() {
  svp_simple_016_001_global_var1 = 0x09;
}

void isr2(){}
void isr3(){}

int main(int argc, char **argv) {

    return 0;
}

// TP
// svp_simple_016_001_global_var1: (R12,W21,R13)
// svp_simple_016_001_global_var1: (R13,W21,R14)
// svp_simple_016_001_global_var1: (R14,W21,R15)

