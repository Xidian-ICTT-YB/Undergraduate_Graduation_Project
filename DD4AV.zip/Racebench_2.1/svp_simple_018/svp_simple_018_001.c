#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <pthread.h>
#include <assert.h>

volatile float svp_simple_018_001_para1;
volatile float svp_simple_018_001_para2;

void task_main() {

  float svp_simple_018_001_perimete = 0;
  float svp_simple_018_001_area = 0;

  float perimete = 0.0;
  float tmp1 = 2 * svp_simple_018_001_para1;
  float tmp2 = tmp1 * svp_simple_018_001_para2;
  svp_simple_018_001_perimete = tmp2;

  float area = 0.0;
  float tmp3 = svp_simple_018_001_para1;
  float tmp4 = tmp3 * svp_simple_018_001_para2;
  float tmp5 = tmp4 * svp_simple_018_001_para2;
  svp_simple_018_001_area = tmp5;
}

void isr1() {
  svp_simple_018_001_para1 = 2.0;
}

void isr2() {
  svp_simple_018_001_para2 = 1.0;
}

void isr3(){}

int main(int argc, char **argv) {

    return 0;
}

