#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <pthread.h>
#include <assert.h>

volatile int svp_simple_022_001_global_var1;
volatile int svp_simple_022_001_global_var2;
volatile int svp_simple_022_001_global_var3;
volatile int svp_simple_022_001_global_array[4];

void task_main() {
//  svp_simple_022_001_global_var1 = rand();
//  svp_simple_022_001_global_var2 = rand();
//  svp_simple_022_001_global_var3 = rand();
  svp_simple_022_001_global_var1 = 1;
  svp_simple_022_001_global_var2 = 2;
  svp_simple_022_001_global_var3 = 3;

  svp_simple_022_001_global_var1 = 0;
  
  if (svp_simple_022_001_global_var1 >= 12) {
    svp_simple_022_001_global_var1 = 12;
  } else {
    svp_simple_022_001_global_var1 = 0;
  }

  int i;
  for (i = 0; i < 4; i++) {
    svp_simple_022_001_global_array[i] = 0;
  }
  svp_simple_022_001_global_var3 = svp_simple_022_001_global_var1;
}

void isr1() {
  svp_simple_022_001_global_var1 = 18;
}

void isr2(){}
void isr3(){}

int main(int argc, char **argv) {
    return 0;
}

