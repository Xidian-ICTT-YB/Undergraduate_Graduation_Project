#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <pthread.h>
#include <assert.h>

volatile int svp_simple_023_001_global_var;
void svp_simple_023_001_func_1(int x);
void svp_simple_023_001_init();

void task_main() {
  svp_simple_023_001_init();
  svp_simple_023_001_func_1(svp_simple_023_001_global_var);  
}
void svp_simple_023_001_init() {
//  svp_simple_023_001_global_var = rand();
  svp_simple_023_001_global_var = 3;

//  init();
}

void svp_simple_023_001_func_1(int var) {
  if (var > 0 && var < 12) {
    int tmp = svp_simple_023_001_global_var + 1;
    svp_simple_023_001_global_var = tmp;
  }
}
void isr1() {
  svp_simple_023_001_global_var = 0;
  svp_simple_023_001_func_1(svp_simple_023_001_global_var);
}

void isr2(){}
void isr3(){}

int main(int argc, char **argv) {


    return 0;
}
