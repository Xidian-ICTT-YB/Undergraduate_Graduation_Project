#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <pthread.h>
#include <assert.h>

volatile int svp_simple_025_001_global_var;
volatile int *svp_simple_025_001_global_array[100];
volatile int *ptr;

void task_main() {
  svp_simple_025_001_global_var = 1;
  ptr = &svp_simple_025_001_global_var;
  *ptr = *ptr + 1;
}

void isr1() {
  svp_simple_025_001_global_var = 0;
}

void isr2(){}
void isr3(){}

int main(int argc, char **argv) {

    return 0;
}

//  *ptr_var = *ptr_var + 1;
//  svp_simple_025_001_global_var = 0;
//  *ptr_var = *ptr_var + 1;

