#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <pthread.h>
#include <assert.h>

volatile int svp_simple_027_001_gloable_var;

int task_main() {
  // svp_simple_027_001_gloable_var = RAND();
  svp_simple_027_001_gloable_var = 411;
  if (svp_simple_027_001_gloable_var > 12) {  
    svp_simple_027_001_gloable_var = 0;       
  }
  return 0;
}

void isr1() {
  int tmp = svp_simple_027_001_gloable_var + 1;
  svp_simple_027_001_gloable_var = tmp;
}

void isr2() {
  int tmp = svp_simple_027_001_gloable_var + 2;
  svp_simple_027_001_gloable_var = tmp;
}

void isr3() {
  int tmp = svp_simple_027_001_gloable_var + 3;
  svp_simple_027_001_gloable_var = tmp;
}

int main(int argc, char **argv) {


    return 0;
}


