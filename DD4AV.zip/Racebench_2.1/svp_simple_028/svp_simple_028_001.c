#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <pthread.h>
#include <assert.h>

volatile int svp_simple_028_001_isr_1_flag;
volatile int svp_simple_028_001_gloable_var;

int task_main() {

  svp_simple_028_001_gloable_var = 15;
  svp_simple_028_001_isr_1_flag = 20;

  if (svp_simple_028_001_gloable_var > 12) {  
    svp_simple_028_001_gloable_var = 0;     
  }
  return 0;
}

void isr1() {
  int tmp = svp_simple_028_001_gloable_var + 1;
  svp_simple_028_001_gloable_var=tmp;
  svp_simple_028_001_isr_1_flag = 0;
}

void isr2() {
  if (svp_simple_028_001_isr_1_flag) {
    int tmp = svp_simple_028_001_gloable_var + 1;
    svp_simple_028_001_gloable_var=tmp;
  }
}

void isr3() {
  int tmp = svp_simple_028_001_gloable_var + 1;
  svp_simple_028_001_gloable_var=tmp;
}

int main(int argc, char **argv) {


    return 0;
}

