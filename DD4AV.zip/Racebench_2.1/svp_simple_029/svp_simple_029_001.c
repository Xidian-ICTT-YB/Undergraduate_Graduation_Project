#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <pthread.h>
#include <assert.h>

volatile int svp_simple_029_001_tm_blocks[4096];
volatile int svp_simple_029_001_average_adjust_flag;
volatile int svp_simple_029_001_average_adjust_count;
//volatile int (*svp_simple_029_001_ptr_GetTmData)(unsigned32);

void task_main() {
  int svp_simple_029_001_local_status = 1;

  for (int i = 0; i < 4096; i++) {
//    svp_simple_029_001_tm_blocks[i] = rand();
     svp_simple_029_001_tm_blocks[i] = 0x01;
  }
  svp_simple_029_001_average_adjust_flag = 0xFF;

//  svp_simple_029_001_ptr_SetTmData = svp_simple_029_001_SetTmData;
//  svp_simple_029_001_ptr_GetTmData = svp_simple_029_001_GetTmData;
//  svp_simple_029_001_ptr_SetSelfCtrlFlag = svp_simple_029_001_SetSelfCtrlFlag;

  if (svp_simple_029_001_local_status == 1) {
      int tmp1;
      int tmp2;
      int ctrl_sts;

      if(tmp1 == 0) {
        tmp1 = 1;
      }

      tmp1 <<= 0;
      tmp2 = 1;
      tmp2 <<= ~tmp2;

      ctrl_sts = svp_simple_029_001_tm_blocks[36];
      ctrl_sts -= svp_simple_029_001_tm_blocks[37];
      ctrl_sts |= tmp1;

      svp_simple_029_001_tm_blocks[36] = ctrl_sts;
  }
}

void isr1() {
  if (svp_simple_029_001_average_adjust_flag == 0xFF) {
    int tmp;
    tmp = svp_simple_029_001_average_adjust_count+1;
    svp_simple_029_001_average_adjust_count = tmp;
    svp_simple_029_001_tm_blocks[36] = svp_simple_029_001_average_adjust_count;
  } else {
    svp_simple_029_001_average_adjust_count = 0;
    svp_simple_029_001_tm_blocks[36] = svp_simple_029_001_average_adjust_count;
  }
}

void isr2(){}
void isr3(){}

int main(int argc, char **argv) {

    return 0;
}

// bug点：
// 1.svp_simple_029_001_tm_blocks[36] <R, #80>, <W, #83>, <W, #83>

// 误报点：
//1.svp_simple_029_001_tm_blocks[36] <R, #80>, <W, #83>, <R, #80>
