#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <pthread.h>
#include <assert.h>


volatile int svp_simple_030_001_isr_1_flag;
volatile int svp_simple_030_001_gloable_var;
volatile unsigned int *svp_simple_030_001_CNT;
int task_main() {
  svp_simple_030_001_gloable_var = 15;
  svp_simple_030_001_isr_1_flag = 1;

  if (svp_simple_030_001_gloable_var > 12) {  
    svp_simple_030_001_gloable_var = 0;       
  }
  return 0;
}


void isr1() {
  int tmp = svp_simple_030_001_gloable_var+1;
  svp_simple_030_001_gloable_var=tmp;
  svp_simple_030_001_isr_1_flag = 0;

}
void isr2() {
  if (svp_simple_030_001_isr_1_flag) {
    int tmp = svp_simple_030_001_gloable_var+1;
    svp_simple_030_001_gloable_var=tmp;
  }
}

void isr3() {
    int tmp = svp_simple_030_001_gloable_var+1;
    svp_simple_030_001_gloable_var=tmp;
}
int main(int argc, char **argv) {

    svp_simple_030_001_CNT = (volatile unsigned int *)malloc(sizeof(unsigned int));
    *svp_simple_030_001_CNT = 24;

    return 0;
}
