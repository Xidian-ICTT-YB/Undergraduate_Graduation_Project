rm -rf ./out_*
rm -rf ./*_out_*