#!/bin/bash

# Define the root directory
ROOT_DIR="/home/rxli/DD4AV/" # 请替换为实际的路径

# Run the scripts
./cleanDIR.sh
./build.sh
$ROOT_DIR/tool/DBDS/run_static.py -y -d 4 ./i2c_pca_isa_3

echo "Data collection complete."