#!/bin/bash

# Define the root directory
# For Mac
if [ $(command uname) == "Darwin" ]; then
	if ! [ -x "$(command -v greadlink)"  ]; then
		brew install coreutils
	fi
	BIN_PATH=$(greadlink -f "$0")
	ROOT_DIR=$(dirname $(dirname $(dirname $BIN_PATH)))
# For Linux
else
	BIN_PATH=$(readlink -f "$0")
	ROOT_DIR=$(dirname $(dirname $(dirname $BIN_PATH)))
fi

export ROOT_DIR=${ROOT_DIR}

# Output CSV file
OUTPUT_FILE="output.csv"
if [ -f "$OUTPUT_FILE" ]; then
    rm "$OUTPUT_FILE"
    echo "Existing $OUTPUT_FILE deleted."
fi
# Create the header of the CSV file
echo "Run,DynamicExecutionTime,bug_depth,AVSched,totalSched,AV_num,AV_Details" > $OUTPUT_FILE

./cleanOUT.sh

# Loop 10 times
for i in {1..10}; do
    echo "Run #$i"

    # Run the scripts
    ./cleanDIR.sh
    ./build.sh
    $ROOT_DIR/tool/DBDS/run.py -y -d 4 ./logger2

    # Find out directories
    for dir in out_logger2_$i; do
        if [ -d "$dir" ]; then
            # Define the file path
            FILE="$dir/Atomicity_Violations/all_ato.txt"

            # Check if the file exists
            if [ -f "$FILE" ]; then
                # Extract the required information from the file using sed
                DYNAMIC_EXECUTION_TIME=$(sed -n '1s/DynamicExecutionTime: \(.*\)/\1/p' "$FILE")
                BUG_DEPTH=$(sed -n '2s/bug_depth: \(.*\)/\1/p' "$FILE")
                AV_SCHED=$(sed -n '3s/AVSched: \(.*\)/\1/p' "$FILE")
                TOTAL_SCHED=$(sed -n '4s/totalSched: \(.*\)/\1/p' "$FILE")
                AV_NUM=$(sed -n '5s/AV num: \(.*\)/\1/p' "$FILE")
                DETAILS=$(sed -n '6,$p' "$FILE" | tr '\n' ' ')

                # Remove leading and trailing spaces from DETAILS
                DETAILS=$(echo "$DETAILS" | xargs)

                # Append the information to the CSV file
                echo "$i,$DYNAMIC_EXECUTION_TIME,$BUG_DEPTH,$AV_SCHED,$TOTAL_SCHED,$AV_NUM,\"$DETAILS\"" >> $OUTPUT_FILE
            else
                echo "File $FILE does not exist"
            fi
        fi
    done
done

./cleanDIR.sh
./cleanOUT.sh

echo "Data collection complete. Results saved to $OUTPUT_FILE"