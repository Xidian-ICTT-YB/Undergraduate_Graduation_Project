#!/usr/bin/env python3

import os
import csv
import argparse
from statistics import mean, mode

# Parse command-line arguments
parser = argparse.ArgumentParser(description='Process some input files.')
parser.add_argument('-w', type=str, required=True, help="Specify the output type: 'DD' or 'RAN' or 'NP'")
args = parser.parse_args()

read_output_file = 'output.csv'
# Set the read and write output file path based on the -w parameter
if args.w == 'DD':
    read_output_file = 'output.csv'
    summary_output_file = 'summary_output.csv'
elif args.w == 'RAN':
    read_output_file = 'output_RAN.csv'
    summary_output_file = 'summary_RAN_output.csv'
elif args.w == 'NP':
    read_output_file = 'output_NP.csv'
    summary_output_file = 'summary_NP_output.csv'
else:
    raise ValueError("Invalid value for -w parameter. Use 'DD' or 'random' or 'NP'.")

# Get the root directory from the environment variable
root_dir = os.path.join(os.environ.get('ROOT_DIR', '/'), 'realworld_AV')

# Define column names
# fieldnames = ["Program", "DynamicExecutionTime", "bug_depth", "firstAVSched", "AVSched", "totalSched", "AV_num",
#               "AV_Details"]
fieldnames = ["Program", "DynamicExecutionTime", "bug_depth", "AVSched", "totalSched", "AV_num", "AV_Details"]

# List used to store summary results
summary_data = []

for folder_name in sorted(os.listdir(root_dir)):
    folder_path = os.path.join(root_dir, folder_name)

    if os.path.isdir(folder_path):
        output_csv_path = os.path.join(folder_path, read_output_file)

        if os.path.exists(output_csv_path):
            columns = {
                "DynamicExecutionTime": [],
                "bug_depth": [],
                # "firstAVSched": [],
                "AVSched": [],
                "totalSched": [],
                "AV_num": [],
                "AV_Details": []
            }

            # Read each output.csv file
            with open(output_csv_path, 'r') as csvfile:
                reader = csv.DictReader(csvfile)
                for row in reader:
                    columns["DynamicExecutionTime"].append(float(row["DynamicExecutionTime"]))
                    columns["bug_depth"].append(int(row["bug_depth"]))
                    # columns["firstAVSched"].append(int(row["firstAVSched"]))
                    columns["AVSched"].append(int(row["AVSched"]))
                    columns["totalSched"].append(int(row["totalSched"]))
                    columns["AV_num"].append(int(row["AV_num"]))
                    columns["AV_Details"].append(row["AV_Details"])

            # maximun of AVNum
            max_av_num = max(columns["AV_num"])
            # AVNum index
            max_av_num_index = columns["AV_num"].index(max_av_num)
            # Get AV_Details according to index
            corresponding_av_details = columns["AV_Details"][max_av_num_index]

            # Calculate the average of each output.csv
            averages = {
                "Program": folder_name,
                "DynamicExecutionTime": round(mean(columns["DynamicExecutionTime"]), 2),  # Keep two decimal places
                "bug_depth": mean(columns["bug_depth"]),
                # "firstAVSched": round(mean(columns["firstAVSched"])),  # Rounding
                "AVSched": round(mean(columns["AVSched"])),  # Rounding
                "totalSched": round(mean(columns["totalSched"])),  # Rounding
                "AV_num": round(mean(columns["AV_num"])),  # Rounding
                "AV_Details": corresponding_av_details  # It may not match AVNum because one is rounded, while the other is the detailed AV information when AVNum is at its maximum. This needs to be executed in detail.
            }

            summary_data.append(averages)

# Write summary results to summary_output.csv
with open(summary_output_file, 'w', newline='') as csvfile:
    writer = csv.DictWriter(csvfile, fieldnames=fieldnames)
    writer.writeheader()
    for data in summary_data:
        writer.writerow(data)

print("The aggregation is complete and the results have been saved to", summary_output_file)
