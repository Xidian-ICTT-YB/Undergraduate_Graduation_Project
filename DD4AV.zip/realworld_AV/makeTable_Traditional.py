#!/usr/bin/env python3

import os
import csv

# 设置根目录和输出文件路径
# 从环境变量中获取根目录
root_dir = os.path.join(os.environ.get('ROOT_DIR', '/'), 'realworld_AV')

summary_output_file = 'summary_output_traditional.csv'

# 定义列名
fieldnames = ["Folder", "TotalSched"]

# 用于存储汇总结果的列表
summary_data = []

# 遍历根目录下的所有文件夹
for folder_name in sorted(os.listdir(root_dir)):
    folder_path = os.path.join(root_dir, folder_name)

    # 确保路径是一个文件夹
    if os.path.isdir(folder_path):
        output_txt_path = os.path.join(folder_path, 'out_static.txt')

        if os.path.exists(output_txt_path):
            # 读取out_static.txt文件
            with open(output_txt_path, 'r') as file:
                line = file.readline()  # 读取第一行
                # 提取数值
                prefix = "totalSched of traditional methods: "

                if line.startswith(prefix):
                    total_sched = int(line.strip().split(prefix)[1])

                    # 将结果添加到汇总数据中
                    summary_data.append({
                        "Folder": folder_name,
                        "TotalSched": total_sched
                    })

# 写入汇总结果到summary_output_traditional.csv
with open(summary_output_file, 'w', newline='') as csvfile:
    writer = csv.DictWriter(csvfile, fieldnames=fieldnames)
    writer.writeheader()
    writer.writerows(summary_data)

print("Traditional汇总完成，结果已保存到", summary_output_file)