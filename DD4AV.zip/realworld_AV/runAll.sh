#!/bin/bash

# Define the root directory
# For Mac
if [ $(command uname) == "Darwin" ]; then
	if ! [ -x "$(command -v greadlink)"  ]; then
		brew install coreutils
	fi
	BIN_PATH=$(greadlink -f "$0")
	ROOT_DIR=$(dirname $(dirname $BIN_PATH))
# For Linux
else
	BIN_PATH=$(readlink -f "$0")
	ROOT_DIR=$(dirname $(dirname $BIN_PATH))
fi

export ROOT_DIR=${ROOT_DIR}

# Go to destination folder
cd "$ROOT_DIR/realworld_AV"

# Traverse the subfolders
for folder in */; do
  if [ -d "$folder" ]; then
    echo "Processing folder: $folder"
    cd "$folder"

    # Go to the Tests subfolder
    cd "$ROOT_DIR/realworld_AV/$folder"

    # execute the program
    ./run.sh

    # Return to parent directory
    cd ..
  fi
done

# statistics
echo "Running Python script to calculate averages..."
python3 $ROOT_DIR/realworld_AV/makeTable.py -w DD

echo "Statistics generated successfully."

