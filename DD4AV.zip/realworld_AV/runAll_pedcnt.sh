#!/bin/bash

# Enter the destination folder
cd "$ROOT_DIR/realworld_AV"

# Traverse the subfolders
for folder in */; do
  if [ -d "$folder" ]; then
    echo "Processing folder: $folder"
    cd "$folder"

    # Enter the Tests subfolder
    cd "$ROOT_DIR/realworld_AV/$folder"

     # Execute build.sh and clean.sh
    ./cleanOUT.sh && ./cleanDIR.sh
    ./build.sh

    # Read the n value in priority.txt
    sed -i -e '$a\' priority.txt
    n=$(wc -l < priority.txt)


    # Remove the backslash at the end of the $folder variable
    folder1="${folder%/}"

for ((i=n; i<=2*(n-1); i++))
do
    # Run test program
    "$ROOT_DIR/tool/DBDS/run_No_Print.py" -y -d $i "./$folder1"

done
    
    # Return to parent directory
    cd ..
  fi
done
