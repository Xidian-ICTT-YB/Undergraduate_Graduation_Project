#!/bin/bash

## Setting environment variables
BIN_PATH=$(readlink -f "$0")
ROOT_DIR=$(dirname $(dirname $BIN_PATH))
export ROOT_DIR=${ROOT_DIR}

# Go to destination folder
cd "$ROOT_DIR/realworld_AV"

# Traverse the subfolders
for folder in */; do
  if [ -d "$folder" ]; then
    echo "Processing folder: $folder"
    cd "$folder"

    # Go to the Tests subfolder
    cd "$ROOT_DIR/realworld_AV/$folder"

    # execute the program
    ./run_TR.sh

##     Execute build.sh and cleanDIR.sh
#    ./cleanDIR.sh && ./build.sh
#
#    # Read the n value in priority.txt
#    sed -i -e '$a\' priority.txt
#    n=$(wc -l < priority.txt)
#    echo $n
#
#    # Remove the backslash at the end of the $folder variable
#    folder1="${folder%/}"
#
#
#    # Run test program
#    "$ROOT_DIR/tool/DBDS/run_static.py" -y -d $((2 * n - 2)) "./$folder1"

     echo 1 >chmod 666 /proc/sys/vm/drop_caches

    # Return to parent directory
    cd ..
  fi
done

# 在所有操作完成后，调用 Python 脚本进行统计
echo "Running Python script to calculate averages..."
python3 $ROOT_DIR/realworld_AV/makeTable_Traditional.py  # 替换为实际的 Python 脚本路径

echo "Statistics generated successfully."

# MAKETABLE
#./maketable.sh

