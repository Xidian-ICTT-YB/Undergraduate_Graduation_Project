#!/bin/bash


# Enter the destination folder
cd "$ROOT_DIR/test"

# Traverse the subfolders
for folder in */; do
  if [ -d "$folder" ]; then
    echo "Processing folder: $folder"
    cd "$folder"

    # Enter the Tests subfolder
    cd "$ROOT_DIR/test/$folder"

    # Execute build.sh and cleanDIR.sh
    ./clean.sh

    # Return to parent directory
    cd ..
  fi
done

