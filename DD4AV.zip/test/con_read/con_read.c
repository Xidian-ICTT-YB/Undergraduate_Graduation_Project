#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <pthread.h>
#include <assert.h>
volatile int y=1;
volatile int x=0,flag=0;

void task_main() {
    x = 1;
    x = 2;
}

void isr1() {
    if(x == 1){
        x = 3;
    }
}

void isr2() {
    if(x == 3){
        x = 4;
    }
}

void isr3(){}


int main(int argc, char **argv) {

    return 0;
}