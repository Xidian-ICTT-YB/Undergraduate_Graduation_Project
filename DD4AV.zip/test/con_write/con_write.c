#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <pthread.h>
#include <assert.h>
volatile int y=1;
volatile int x=0,flag=0;

void task_main() {
    x = 1;
}

void isr1() {
    int b,c;
    if(x == 1){
        b = x;
        c = x + 1;
    }
    x = b+c;
}

void isr2() {
    x = 5;
}

void isr3(){}

int main(int argc, char **argv) {

    return 0;
}