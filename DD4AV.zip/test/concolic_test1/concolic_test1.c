#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <pthread.h>
#include <assert.h>

volatile int x=0;
volatile int flag=0;
volatile int MAX_LENGTH = 10;
volatile int TRIGGER = 9;

void task_main() {
    int input;
    flag = 1;
    flag = 4;
    // 根据输入变量 input 的值选择不同的路径
    if (input == 1) {
        printf("Task: Path 1 (input == 1)\n");
        x = 10;  // 修改全局变量 x 的值
    } else if (input == 2) {
        printf("Task: Path 2 (input == 2)\n");
        x = 20;  // 修改全局变量 x 的值
    } else {
        printf("Task: Default Path (input != 1 && input != 2)\n");
        x = 30;  // 修改全局变量 x 的值
    }

}

void isr1() {
    if (flag == 1) {
        x = 2;
    }
}

void isr2() {
    if (x == 2) {
        x = 5;
    }
}

void isr3(){}

int main(int argc, char **argv) {

    return 0;
}