#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <pthread.h>
#include <assert.h>
volatile int x=0,flag=0;

void func1() {
    flag = 1;
    flag = 11;
}

void task_main() {
    func1();
    func1();
}

void isr1() {
    func1();
}

void isr2() {
    if(flag == 1){
        x = 3;
    }
}

void isr3(){}

int main(int argc, char **argv) {

    return 0;
}