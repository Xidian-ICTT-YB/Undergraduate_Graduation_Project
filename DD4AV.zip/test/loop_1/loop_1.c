#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <pthread.h>
#include <assert.h>
volatile int y=1;
volatile int x=0;

void task_main() {
    y = 1;
    for(int i = 0; i < 10 ; i++){
        if(i == 9){
            y = 0;
        }
    }
}

void isr1() {
    if(y>0){
        x = 1;
    }
}


void isr2() {
    if(x == 1){
        x = 10;
    }
}

void isr3(){}

int main(int argc, char **argv) {


    return 0;
}