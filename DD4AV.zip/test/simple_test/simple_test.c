#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <pthread.h>
#include <assert.h>

volatile int x=0;
volatile int flag=0;
volatile int MAX_LENGTH = 10;
volatile int TRIGGER = 9;

void task_main() {
    flag = 1;
    for(int i = 0 ; i < MAX_LENGTH ; i++) {
        if(i == TRIGGER) {
            flag = 3;
        }
    }

}

void isr1() {
    if (flag == 1) {
        x = 2;
    }
}

void isr2() {
    if (x == 2) {
        x = 5;
    }
}

void isr3(){}

int main(int argc, char **argv) {

    return 0;
}