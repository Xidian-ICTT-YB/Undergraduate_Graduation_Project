#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <pthread.h>
#include <assert.h>

volatile int x=0;
volatile int y=0;

void task_main() {
    x = 1;
//    if(x != 1){
//        y = 1;
//    }
    x = 2;
    x = 3;
    x = 4;
    x = 5;
    x = 6;
}

void isr1() {
    if (x == 1) {
        y = 2;
    }
}

void isr2() {
    x = 5;
    y = 5;
}

void isr3(){}


int main(int argc, char **argv) {


    return 0;
}


