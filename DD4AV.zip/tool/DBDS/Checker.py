class ListChecker:
    def __init__(self):
        # 存储生成的列表及其空间哈希
        self.generated_space_lists = {}
        self.generated_loc_hashes = set()

    def compute_space_hash(self, lst):
        """计算列表的哈希值"""
        return hash(tuple(tuple(sorted(sublist)) for sublist in sorted(lst)))

    def is_subset(self, new_list, existing_list):
        """检查new_list是否为existing_list的子集"""
        # 将列表展平并排序
        flat_new = sorted([item for sublist in new_list for item in sublist])
        flat_existing = sorted([item for sublist in existing_list for item in sublist])
        # 判断new_list的元素是否全部包含在existing_list中
        return all(item in flat_existing for item in flat_new)

    def add_list_by_space(self, new_list):
        """检查并添加新生成的列表"""
        new_list_hash = self.compute_space_hash(new_list)
        # 遍历之前生成的列表，检查是否有超集关系
        for existing_hash, existing_list in self.generated_space_lists.items():
            if self.is_subset(new_list, existing_list):
                # print(f"新列表 {new_list} 是已生成列表 {existing_list} 的子集，跳过处理。")
                return False

        # 如果没有超集关系，添加新列表
        self.generated_space_lists[new_list_hash] = new_list
        # print(f"添加新列表: {new_list}")
        return True

    def compute_2d_loc_hash(self,two_d_list):
        # 将每个子列表转换为元组
        tuple_representation = tuple(tuple(sublist) for sublist in two_d_list)
        # 计算整个结构的哈希值
        return hash(tuple_representation)


    def add_list_by_loc(self, new_list):
        """检查并添加新生成的列表"""
        new_list_hash = self.compute_2d_loc_hash(new_list)
        # 遍历之前生成的列表，检查是否有相同列表
        if new_list_hash in self.generated_loc_hashes:
            return True  # 表示重复
        else:
            self.generated_loc_hashes.add(new_list_hash)
            print(f"添加新列表: {new_list}")
            return False  # 表示不重复
