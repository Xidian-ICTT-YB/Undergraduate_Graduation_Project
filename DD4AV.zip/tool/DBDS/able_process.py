#!/usr/bin/env python3

import sys
import re
from collections import Counter
from external_def import transform_serial_inter_to_serial_loc_inter, get_yield_pattern
import os
import copy


def parse_able_info(file_path):
    actions = []
    with open(file_path, 'r') as file:
        able_info = file.read().strip()
        if not able_info:
            print("no able info in C program")
            # 如果文件为空，则直接返回空列表
            return actions

        for line in able_info.split('\n'):
            parts = line.split(', ')
            line_num = int(parts[0].split(': ')[1])
            action_type = parts[1].split(': ')[1]
            interrupt_number = int(parts[2].split(': ')[1])
            task = parts[3].split(': ')[1]
            priority = int(parts[4].split(': ')[1])
            actions.append({
                'line': line_num,
                'type': action_type,
                'interrupt': interrupt_number,
                'task': task,
                'priority': priority
            })
    return actions


def insert_into_schedule(absolute_loc_inter, able_info_line, inter, insert_before):
    new_schedules = []
    new_inter_schedules = []
    line_num = able_info_line['line']
    priority = able_info_line['priority']
    able_info_line_str = f"{able_info_line['type'][:3]}({able_info_line['interrupt']})"

    if insert_before:
        for i in range(len(absolute_loc_inter)):
            for j in range(len(absolute_loc_inter[i])):
                if isinstance(absolute_loc_inter[i][j], int) and inter[i][j] == priority:
                    if absolute_loc_inter[i][j] > line_num:
                        new_schedule = [sublist[:] for sublist in absolute_loc_inter]
                        new_inter = [sublist[:] for sublist in inter]
                        new_schedule[i].insert(j, able_info_line_str)
                        new_inter[i].insert(j, priority)  # 在相应位置插入 priority
                        new_schedules.append(new_schedule)
                        new_inter_schedules.append(new_inter)
                        return new_schedules, new_inter_schedules

    else:
        for i in range(len(absolute_loc_inter) - 1, -1, -1):
            for j in range(len(absolute_loc_inter[i]) - 1, -1, -1):
                if isinstance(absolute_loc_inter[i][j], int) and inter[i][j] == priority:
                    if absolute_loc_inter[i][j] < line_num:
                        new_schedule = [sublist[:] for sublist in absolute_loc_inter]
                        new_inter = [sublist[:] for sublist in inter]
                        new_schedule[i].insert(j + 1, able_info_line_str)
                        new_inter[i].insert(j + 1, priority)  # 在相应位置插入 priority
                        new_schedules.append(new_schedule)
                        new_inter_schedules.append(new_inter)
                        return new_schedules, new_inter_schedules
    return new_schedules, new_inter_schedules

def insert_enable_disable(absolute_loc_inter, able_info_list, inter):
    insert_able_absolute_loc_inters = [absolute_loc_inter]
    inter_schedules = [inter]

    for able_info_line in able_info_list:
        new_schedules = []
        insert_able_priority_inters = []
        for schedule, inter_schedule in zip(insert_able_absolute_loc_inters, inter_schedules):
            scheds, inters = insert_into_schedule(schedule, able_info_line, inter_schedule, insert_before=True)
            new_schedules.extend(scheds)
            insert_able_priority_inters.extend(inters)
            scheds, inters = insert_into_schedule(schedule, able_info_line, inter_schedule, insert_before=False)
            new_schedules.extend(scheds)
            insert_able_priority_inters.extend(inters)

        # 去重处理
        unique_new_schedules = []
        unique_new_inter_schedules = []

        for sched, inter_sched in zip(new_schedules, insert_able_priority_inters):
            if sched not in unique_new_schedules:
                unique_new_schedules.append(sched)
                unique_new_inter_schedules.append(inter_sched)

        insert_able_absolute_loc_inters = unique_new_schedules
        inter_schedules = unique_new_inter_schedules

    return insert_able_absolute_loc_inters, inter_schedules

def validate_logic(merge_inter):
    N = 10  # 设置最大中断信号编号
    active_interrupts = {i: True for i in range(N + 1)}  # 初始化所有中断信号为 True

    merge_inter_copy = copy.deepcopy(merge_inter)
    remove_inter = False
    for period_index, period in enumerate(merge_inter_copy):
        for item in period:
            if isinstance(item, str):
                action, num = item.split("(")
                num = int(num[:-1])
                if action == 'dis':
                    active_interrupts[num] = False
                elif action == 'ena':
                    active_interrupts[num] = True
            else:
                if item in active_interrupts and not active_interrupts[item]:
                    # 方式 1：直接从merge_inter中删掉当前item
                    # period.remove(item)

                    # 方式 2: 如果是最后一个周期里的点违规，不用删。如果是其他点，那么整个序列删掉
                    if period_index != len(merge_inter_copy) - 1:
                        remove_inter = True
                    break
        if remove_inter:
            break
        # 方式 2 end

    if remove_inter:
        return []
    else:
        # 对当前merge_inter进行还原，去掉其中的dis(xx)和ena(xx)
        restored_inter = [
            [item for item in period if not isinstance(item, str)]
            for period in merge_inter_copy
            if period  # 只保留不为空的 period
        ]
        return restored_inter


def merge_inter_lists(absolute_loc_inters, insert_able_priority_inters):

    merged_inters = []
    for abs_inter, pri_inter in zip(absolute_loc_inters, insert_able_priority_inters):
        merged_inter = []
        for abs_period, pri_period in zip(abs_inter, pri_inter):
            merged_sublist = []
            for abs_item, pri_item in zip(abs_period, pri_period):
                if isinstance(abs_item, str) and ('ena' in abs_item or 'dis' in abs_item):
                    merged_sublist.append(abs_item)
                else:
                    merged_sublist.append(pri_item)
            merged_inter.append(merged_sublist)
        merged_inters.append(merged_inter)

    return merged_inters

def deduplication_and_remove_empty(inters):
    unique_new_schedules = []

    for inter in inters:
        if inter != []:
            if inter not in unique_new_schedules:
                unique_new_schedules.append(inter)
    return unique_new_schedules

def main(kpLocArray, kpNumArray, inter, able_info):
    if sum(len(sublist) for sublist in inter) != len(kpLocArray):
        return "Inter elements count does not match kpLocArray length"

    # 形成绝对位置信息
    absolute_loc_inter = transform_serial_inter_to_serial_loc_inter(kpLocArray, kpNumArray, inter)

    # 读取静态分析得到的 ableInfo.xxx
    ableInfo_fileName = "/home/rxli/DD4AV/test/loop_1/ableInfo.test"
    able_info_list = parse_able_info(ableInfo_fileName)

    # 往 sched 插 enable/disable
    insert_able_absolute_loc_inters, insert_able_priority_inters = insert_enable_disable(absolute_loc_inter, able_info_list, inter)

    merge_inters = merge_inter_lists(insert_able_absolute_loc_inters, insert_able_priority_inters)

    # 检测 enable/disable 逻辑是否正确
    restored_inters = []
    for merge_inter in merge_inters:
        validate_inters = validate_logic(merge_inter)
        if validate_inters:
            restored_inters.append(validate_inters)
    restored_inters = deduplication_and_remove_empty(restored_inters)

    # print(restored_inters)


if __name__ == "__main__":
    # # Example usage
    # kpLocArray = [15, 16, 20, 22, 23, 28, 34]
    # kpOrderArray = [1, 2, 3, 6, 7, 4, 5]
    # kpNumArray = [2, 3, 1, 1]
    # inter = [[0, 0], [1], [2], [3], [1, 1]]
    # able_info = """
    # Line: 14, Type: disable, Interrupt Number: 2, Task: task_main
    # Line: 21, Type: enable, Interrupt Number: 2, Task: isr1
    # """

    # # Example usage
    # kpLocArray = [15, 16, 20, 22, 23, 28, 34]
    # kpNumArray = [2, 3, 1, 1]
    # inter = [[0], [1], [2], [3], [1, 1], [0]]
    # able_info = """
    # Line: 14, Type: disable, Interrupt Number: 2, Task: task_main
    # Line: 21, Type: enable, Interrupt Number: 2, Task: isr1
    # """

    # Example usage
    # kpLocArray = [15, 16, 20, 22, 23, 28]
    # kpNumArray = [2, 3, 1]
    # inter = [[0,0], [1], [2], [1, 1]]
    # able_info = """
    # Line: 14, Type: disable, Interrupt Number: 2, Task: task_main
    # Line: 21, Type: enable, Interrupt Number: 2, Task: isr1
    # """

    # kpLocArray = [15, 16, 20, 22, 28]
    # kpNumArray = [2, 2, 1]
    # inter = [[1,1],[0,0],[2]]
    # able_info = """
    # Line: 14, Type: disable, Interrupt Number: 2, Task: task_main
    # Line: 21, Type: enable, Interrupt Number: 2, Task: isr1
    # """

    kpLocArray = [15, 16, 20, 22, 23, 28]
    kpNumArray = [2, 3, 1]
    inter = [[0],[2],[1,1,1],[0]]
    able_info = """
    Line: 14, Type: disable, Interrupt Number: 2, Task: task_main
    Line: 21, Type: enable, Interrupt Number: 2, Task: isr1
    """


    main(kpLocArray, kpNumArray, inter, able_info)

