def generateTriplelet(list):
    triplelist = []
    for first in range(len(list)-2):
        for third in range(first+1,len(list)):
            if list[third][2] == list[first][2]:
                if third == first+1:
                    break
                for second in range(first+1,third):
                    triplelist.append([list[first], list[second], list[third]])
                break
    return triplelist

def match_patterns(list):
    patterns = [
        ['R', 'W', 'R'],
        ['W', 'W', 'R'],
        ['R', 'W', 'W'],
        ['W', 'R', 'W']
    ]
    return list in patterns

def D4AV(ComSet):
    AVSet = set()
    Ato = {}
    indexedComSet = [(index,) + tuple(com) for index, com in enumerate(ComSet)]
    indexedComSet.sort(key=lambda x: (x[1], x[0]))
    Triplelist = []
    for index, order, LineNum, ad, op, func in indexedComSet:
        if ad not in Ato:
            Ato[ad] = []
        Ato[ad].append([LineNum, op, func, index])
    for each in Ato:
        if len(Ato[each]) >= 3:
            Triplelist = generateTriplelet(Ato[each])
        for each in Triplelist:
            op1, op2, op3 = each[0][1], each[1][1], each[2][1]
            if (match_patterns([op1, op2, op3]) and each[0][0] != each[2][0] and each[0][2] == each[2][2] and each[1][0]>=each[0][0] and each[1][0]>=each[2][0]):
                AVSet.add(((each[0][1], each[0][0]), (each[1][1], each[1][0]), (each[2][1], each[2][0])))
    # for each in AVSet:
    #     print(each)
    return AVSet


# for example : [23, 20, 13, 'W', 'svp_simple_001_001_main']
# timestamp:23 loc:20 address:13 op:W function:svp_simple_001_001_main