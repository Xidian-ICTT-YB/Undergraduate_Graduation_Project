#!/usr/bin/env python3

import io, re, sys, os
from ast import literal_eval
import numpy as np
from ctypes import *
from sysv_ipc import * # Doc: http://semanchuk.com/philip/sysv_ipc
# to install: pip3 install sysv_ipc

def formateTime(seconds):
    '''
    Turn a time interval in seconds into the format of hh:mm:ss.sssss
    '''
    hours, rem = divmod(seconds, 3600)
    minutes, s = divmod(rem, 60)
    return '{:0>2}:{:0>2}:{:08.5f}'.format(int(hours), int(minutes), s)

# rxadd
def formateTimeSeconds(seconds):
    return '{:08.5f}'.format(seconds)

# align pattern list (filled with zero)
def filled_with_zero(pattern, M):
    for eachSubList in pattern:
        if len(eachSubList) < M:
            eachSubList += [0 for i in range(M-len(eachSubList))]

def calculate_coverage_hashID(kpLocArray, Num, kpNumArray, N, SHARE_ARRAY_SIZE):
    hashID = 0
    if Num > SHARE_ARRAY_SIZE:
        Num = SHARE_ARRAY_SIZE
    for i in range(0, Num):
        hashID = hashID + kpLocArray[i]
    m = 1
    for i in range(0, N):
        m = (kpNumArray[i] * m) % 10000000
    hashID = hashID + m
    return hashID

def add_to_explore_dict(waited_to_explore, coverage_hashID, inter, pattern, N, M, kpNumList, kpLocList, prefix):
    if coverage_hashID in waited_to_explore:
        saved_prefix = [x for tup in waited_to_explore[coverage_hashID][6] for x in tup]
        new_prefix = [x for tup in prefix for x in tup]
        if len(saved_prefix) < len(new_prefix):
            tmpList = [inter, pattern, N, M, kpNumList, kpLocList, prefix]
            waited_to_explore[coverage_hashID] = tmpList
        else:
            return
    else:
        tmpList = [inter, pattern, N, M, kpNumList, kpLocList, prefix]
        waited_to_explore[coverage_hashID] = tmpList

def print_Info_from_shm(N, M, TupleFirst, kpNumArray, kpLocArray, kpOrderArray, prefix, coverage_hashID, zero_in_KP, Flag = False):
    if N != None:
        print("ThreadNum: ", N)
    if M != None:
        print("MaxKpNum: ", M)
    if TupleFirst != None:
        print("TupleScheduling:", TupleFirst)

    print("kpNumArray: ", end = '')
    if kpNumArray != None:
        for i in range(0, N + zero_in_KP):
            print(kpNumArray[i], end = " ")
        print()

    if Flag:
        if kpLocArray is not None and kpOrderArray is not None:
            print("kpLocArray\tkpOrderArray")
            for i in range(M * (N + zero_in_KP)):
                print(f"{kpLocArray[i]}\t{kpOrderArray[i]}")

    print("prefix:", prefix)
    if coverage_hashID != None:
        print("coverage_hashID:", coverage_hashID)

def is_redundant(inter):
    if inter != [] and len(inter) >= 2:
        if type(inter[-1]) == list:
            if len(set(inter[-1])) == 1:
                if len(set(inter[-2])) == 1 and set(inter[-2]) != set(inter[-1]):
                    return False
                else:
                    return True
            else:
                return True
        else:
            return True
    else:
        return True

def is_redundant_with_prefix(inter, prefix):
    if inter != [] and len(inter) >= 2:
        if type(inter[0]) == list:
            if len(set(inter[0])) == 1 and set(prefix[0]) == set(inter[0]):
                ''' # outdated
                if len(prefix) == 1:
                    return False
                else:
                    for i in range(0, len(prefix)):
                        if i < len(prefix) - 1 and len(prefix) <= len(inter):
                            if prefix[i] != inter[i]:
                                return True
                        else:
                            if set(prefix[i]) == set(inter[i]):
                                return False
                            else:
                                return True
                '''
                if len(prefix[0]) <= len(inter[0]):
                    return False
                else:
                    return True
            else:
                return True
        else:
            return True
    else:
        return True

def doesZeroInList(kpNumArray, N):
    for i in range(0, N):
        print(N)
        print(i, kpNumArray[i])
        if kpNumArray[i] == 0:
            return False
    return True

def getMaxNuminPattern(pattern_list):
    max = 0
    for each in pattern_list:
        if sum(each) > max:
            max = sum(each)
    return max

def zero_num(kpNumArray, kpMaxNumArray, N):
    
    zero_num = -1
    zero_num_save = -1

    for i in range(0, N): # prevent all 0 in kpNumArray
        if not kpNumArray[i] == 0:
            zero_num = 0
            break

    if not zero_num == 0:
        return 0

    for limit in range(0, 3):
        if zero_num_save == zero_num:
            break
        else:
            zero_num_save = zero_num
        
        zero_num_save = zero_num
        zero_num_for_kpNumArray = 0
        zero_num_for_kpMaxNumArray = 0
        for i in range(0, N + zero_num):
            if kpNumArray[i] == 0:
                zero_num_for_kpNumArray = zero_num_for_kpNumArray + 1
            if kpMaxNumArray[i] == 0:
                zero_num_for_kpMaxNumArray = zero_num_for_kpMaxNumArray + 1
        
        if zero_num_for_kpNumArray <= zero_num_for_kpMaxNumArray:
            zero_num = zero_num_for_kpNumArray
        else:
            zero_num = zero_num_for_kpMaxNumArray
    
    return zero_num

def transform_serial_inter_to_serial_loc_inter(kpLocArray, kpNumArray, inter):
    new_inter = []

    # 寻找各个优先级的 kpLocArray 的位置,第一个元素为0
    kpLocStart = [0]
    cumulative_sum = 0
    # 遍历各个优先级的关键操作个数列表
    for koNum in kpNumArray[:-1]:
        cumulative_sum += koNum
        # 将累积和添加到新列表中
        kpLocStart.append(cumulative_sum)

    # 遍历每个周期
    for each_period in inter:
        new_sublist = []
        # 每个周期的每个关键操作
        ko = each_period[0]
        start_index = kpLocStart[ko]
        length = len(each_period)
        # 绝对位置列表
        new_inter.append(kpLocArray[start_index:start_index + length])
        # 将要处理的关键操作下标
        kpLocStart[ko] += length
    return new_inter

def transform_act_to_period(act_loc_sched_expand, outInter):
    act_loc_sched_period_type = []
    outInter_period_type = []

    tmp_inter = []
    tmp_loc_sched = []
    for i in range(0, len(act_loc_sched_expand)):
        tmp_inter.append(outInter[i])
        tmp_loc_sched.append(act_loc_sched_expand[i])
        if i != len(act_loc_sched_expand) - 1 and outInter[i+1] != outInter[i]:
            outInter_period_type.append(tmp_inter)
            act_loc_sched_period_type.append(tmp_loc_sched)
            tmp_inter = []
            tmp_loc_sched = []
        if i == len(act_loc_sched_expand) - 1:
            outInter_period_type.append(tmp_inter)
            act_loc_sched_period_type.append(tmp_loc_sched)

    return outInter_period_type,act_loc_sched_period_type




def get_yield_pattern(inter, N, kpNumArray):
    if inter == None:
        return None
    pattern = []
    idx = [0] * N
    for i in range(N):
        pattern.append([0] * kpNumArray[i])
    # 遍历sched，获得每一个周期列表
    for p in inter:
        # 遍历该周期
        for n in p:
            # 记录之前周期已经执行了的关键点数（n和线程ID相同），并且idx[n]等于下一个没有执行到的关键点下标
            idx[n] += 1
        for i in range(N):
            try:
                # 没执行到的，则先暂时放到下一周期。即等待的周期数pattern+1
                pattern[i][idx[i]] += 1
            except:
                pass
    return pattern


def read_priority(file_path):  # rxadd
    priority_dict = {}
    try:
        with open(file_path, 'r') as file:
            for line in file:
                line = line.strip()
                if line:
                    func_name, priority = line.split(':')
                    priority_dict[func_name] = int(priority)
    except FileNotFoundError:
        print("File not found:", file_path)
    return priority_dict


def get_priority(func_name, priority_dict): # rxadd
    if func_name in priority_dict:
        return priority_dict[func_name]
    else:
        return None


def order_to_act_sched_serialize(mid_info): #rxadd
    # sorted_Loc_info_list: [order, loc, funcName]

    sorted_Loc_info_list = sorted(mid_info, key=lambda x: x[0])

    actual_sched = []
    actual_loc_sched = []

    priority_file_path = "priority.txt"
    priority_dict = read_priority(priority_file_path)

    for each in sorted_Loc_info_list:
        function_name = each[4]
        priority = get_priority(function_name, priority_dict)
        actual_sched.append(priority)
        actual_loc_sched.append(each[1])

    transformed_schedule = []
    current_group = [actual_sched[0]]

    for i in range(1, len(actual_sched)):
        if actual_sched[i] != actual_sched[i-1]:
            transformed_schedule.append(current_group)
            current_group = [actual_sched[i]]
        else:
            current_group.append(actual_sched[i])

    transformed_schedule.append(current_group)  # 添加最后一个分组
    transformed_loc_sched = []
    index_start = 0
    for period in range(len(transformed_schedule)):
        leng = len(transformed_schedule[period])
        current_loc_group = actual_loc_sched[index_start:index_start+leng]
        transformed_loc_sched.append(current_loc_group)
        index_start = index_start + leng

    return transformed_schedule, transformed_loc_sched


def merge_info_StaticDynamic(SA_Info, DD_Info):  # kladd
    result = []
    for item1 in DD_Info:  # item1:[kpOrder, loc]
        found = False
        item1_val = item1[1]
        for item2 in SA_Info:  # item2:[address, op, loc, func]
            item2_val = item2[2]
            if item1_val == item2_val:
                merged_item = item1 + item2[:2] + item2[3:]
                result.append(merged_item)
                found = True
                break
        if not found:
            result.append(item1)
    return result


def get_no_zero_kpNumArray(kpNumArray, N, zero_in_KP):
    no_zero_kpNumArray = []
    for i in range(0, N + zero_in_KP):
        no_zero_kpNumArray.append(kpNumArray[i])
    return no_zero_kpNumArray

def get_no_zero_kpLocArray(kpLocArray, N, M, zero_in_KP):
    no_zero_kpLocArray = []
    for i in range(M * (N + zero_in_KP)):
        if kpLocArray[i] != 0:
            no_zero_kpLocArray.append(kpLocArray[i])
    return no_zero_kpLocArray


def check_and_update_kpNumMaxArray(N, kpMaxNumArray, kpNumArray, zero_in_KP):
    hasNewMax = False
    for i in range(0, N + zero_in_KP):
        if kpNumArray[i] > kpMaxNumArray[i]:
            kpMaxNumArray[i] = kpNumArray[i]
            hasNewMax = True
    return hasNewMax

def new_max_kpNumArray(N, kpNumArray, parentArray, zero_in_KP):
    hasNewMax = False
    for i in range(0, N + zero_in_KP):
        if kpNumArray[i] > parentArray[i]:
            parentArray[i] = kpNumArray[i]
            hasNewMax = True
    return hasNewMax


def load_able_file(exename):
    if '/' in exename:
        SlashIndex = exename.rfind('/')
        Able_Info_FileName = exename[0:SlashIndex + 1] + "ableInfo." + exename[SlashIndex + 1:]
    else:
        Able_Info_FileName = "ableInfo." + exename
    return Able_Info_FileName

def load_static_file(exename):
    if '/' in exename:
        SlashIndex = exename.rfind('/')
        Static_Analysis_FileName = exename[0:SlashIndex + 1] + "static_analysis." + exename[SlashIndex + 1:]
    else:
        Static_Analysis_FileName = "static_analysis." + exename
    return Static_Analysis_FileName

def load_mempair_file(varNumConsidered, memPairConsidered, exename):
    LoadMemInfoFile = 0
    if '/' in exename:
        SlashIndex = exename.rfind('/')
        memInfoFile = exename[0:SlashIndex + 1] + "mempair." + exename[SlashIndex + 1:] + ".npz"
    else:
        memInfoFile = "mempair." + exename + ".npz"
    if varNumConsidered != 0 or memPairConsidered != 0:
        if os.path.exists(memInfoFile):
            LoadMemInfoFile = 1
            print("memInfoFile:", memInfoFile)
        else:
            print("cannot find memInfoFile: " + memInfoFile + ".")
            sys.exit()
    return LoadMemInfoFile, memInfoFile

def load_npz_data(LoadMemInfoFile, memInfoFile):
    pureSoList = []
    memGroupList = []
    memPairList = []
    if LoadMemInfoFile == 1:
        if not os.path.exists(memInfoFile):
            print("memInfoFile " + memInfoFile + " not exists.")
            sys.exit()
        NPZ = np.load(memInfoFile, allow_pickle=True)
        pureSoList = NPZ["arr_0"].tolist()
        memGroupList = NPZ["arr_1"].tolist()
        memPairList = NPZ["arr_2"].tolist()

        print("\033[34mpureSoList: \033[0m")
        for each in pureSoList:
            print(each)
        print()

        print("\033[34mmemGroupList: \033[0m")
        for each in memGroupList:
            print(each)
        print()
    return pureSoList,memGroupList,memPairList

def create_folder(args, recordERR):
    # create output folder for saveing the error interleavings
    if '/' in args[0]:
        folder_name = "out_" + args[0].split('/')[-1]
    else:
        folder_name = "out_" + args[0]

    fi = 1
    while (os.path.exists(folder_name + "_" + str(fi))):
        fi = fi + 1

    folder_name = folder_name + "_" + str(fi)
    os.makedirs(folder_name + "/" + "Atomicity_Violations")
    if recordERR == 1:
        os.makedirs(folder_name + "/" + "Errors")
        os.makedirs(folder_name + "/" + "DiffResult")
        os.makedirs(folder_name + "/" + "Timeouts")
    return folder_name



def get_info_from_staticanalysis(filename):  # kladd
    static_info = []
    if os.path.exists(filename):
        with open(filename, 'r') as file:
            for line in file:
                try:
                    parsed_line = literal_eval(line.strip())
                    static_info.append(parsed_line)
                except SyntaxError:
                    print(f"Ignoring line due to syntax error: {line.strip()}")
                except ValueError:
                    print(f"Ignoring line due to value error: {line.strip()}")

        for item in static_info:
            parts = item[2].split(':')
            if len(parts) == 2:
                number = parts[1]
                if number.isdigit():
                    item[2] = int(number)
    else:
        print(f"Static analysis file {filename} does not exist.")

    return static_info

def get_location_time_info(kpTimeArray, kpLocArray):  # kladd
    cnt = 0
    Loc_info_list = []
    for i in range(len(kpLocArray)):
        cnt += 1
        if kpLocArray[i] != 0:
            Loc_info_list.append([kpTimeArray[i], kpLocArray[i]])
            # print(kpTimeArray[i],kpLocArray[i])

    return Loc_info_list

def get_location_order_info(kpLocArray, kpOrderArray):  # rxadd
    cnt = 0
    loc_order_info_list = []
    for i in range(len(kpLocArray)):
        cnt += 1
        if kpLocArray[i] != 0:
            loc_order_info_list.append([kpOrderArray[i], kpLocArray[i]])
            # print(kpOrderArray[i],kpLocArray[i])

    return loc_order_info_list