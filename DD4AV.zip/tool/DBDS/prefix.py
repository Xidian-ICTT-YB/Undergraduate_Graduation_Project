def find_first_differ(exp_loc_sched, act_loc_sched, periodId):
    """
    Helper function to check if list1 is a sublist of list2.
    """
    for i in range(len(act_loc_sched[periodId])):
        sub = False
        for j in range(len(exp_loc_sched[periodId])):
            if exp_loc_sched[periodId][j] == act_loc_sched[periodId][i]:
                sub = True
                break
        if not sub:
            return i
    return -1

def prefix_generation(exp_loc_sched, act_loc_sched, exp_sched, act_sched):
    prefix = []
    prefix_loc = []
    if len(exp_sched) != len(act_sched):
        return prefix, prefix_loc
    for periodId in range(len(exp_loc_sched)):
        first_differ_index = find_first_differ(exp_loc_sched, act_loc_sched, periodId)
        if first_differ_index == -1:
            # No new key operations are discovered
            continue
        else:
            if first_differ_index == 0:
                prefix = act_sched[0: periodId]
                prefix_loc = act_loc_sched[0: periodId]
                return prefix, prefix_loc
            else:
                prefix = act_sched[0: periodId] + [act_sched[periodId][0:first_differ_index]]
                prefix_loc = act_loc_sched[0: periodId] + [act_loc_sched[periodId][0:first_differ_index]]
                return prefix, prefix_loc
    return prefix, prefix_loc

# Testing the function
def test_prefix_generation():
    test_cases = [
        ([[1, 2, 3], [10, 11]], [[1, 2, 3], [12]]),
        ([[1, 2, 3], [10, 11]], [[1, 2, 3], [8, 10]]),
        ([[1, 2, 3], [10, 11]], [[1, 2], [10]]),
        ([[1, 2, 3], [10, 11]], [[1, 2], [10, 12]]),
        ([[1, 3], [10, 11]], [[1, 2], [10, 12]]),
        ([[1, 2, 3], [1, 2, 3], [10, 11]], [[1, 2, 3], [1, 2, 3], [10, 11, 12]]),
        ([[1, 2, 3], [10, 11], [20]], [[1, 2, 3], [10, 11, 12], [20, 21]]),
        ([[38], [46, 57, 58, 60, 63], [64, 74, 76, 79], [40, 42, 43]],[[38], [57, 60, 61, 63, 64], [42], [74], [43, 46], [76, 79, 80]])
    ]

    for i, (exp_sched, act_sched) in enumerate(test_cases):
        print(f"Test case {i + 1}: exp_sched = {exp_sched}, act_sched = {act_sched}")
        result = prefix_generation(exp_sched, act_sched)
        print(f"Result: {result}\n")


if __name__ == '__main__':
    test_prefix_generation()