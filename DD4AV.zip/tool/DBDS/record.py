#!/usr/bin/env python3

import io, re, sys, os
from external_def import formateTimeSeconds

def get_ASAN_error_type(context_bytes):
    try:
        context_strings = context_bytes.decode("utf-8")
        context_io = io.StringIO(context_strings)
        context = context_io.readlines()
    except:
        return '', ''
    CrashType = ''
    CrashDesc = ''
    for line in context:
        line = line.strip().strip(':') # delete the last ':'
        if "ERROR: AddressSanitizer: requested allocation size" in line or "WARNING: AddressSanitizer: requested allocation size" in line:
            CrashType = 'Failed-to-allocate'
        elif "ERROR: AddressSanitizer:" in line or "WARNING: ThreadSanitizer:" in line or "ERROR: ThreadSanitizer:" in line:
            rindex = line.rfind(':')
            tmp = line[rindex+1:].strip()
            left, right = tmp.split(' ',1)
            if left == "attempting":
                left, right = right.split(' ',1)
            if left == "data":
                left = "data-race"
            CrashType = left.strip()
        elif "WARNING: AddressSanitizer" in line or "ERROR: AddressSanitizer" in line:
            rindex = line.find(':')
            if "failed to allocate" in  line and 'WARNING' in line:
                CrashType = 'Failed-to-allocate'
            elif "failed to allocate" in  line and 'ERROR' in line:
                CrashType = 'Failed-to-allocate'
            else:
                tmp = line[rindex+1:].strip()
                left, right = tmp.split(' ',1)
                CrashType = left.strip()
        elif "SUMMARY: AddressSanitizer" in line or "SUMMARY: ThreadSanitizer" in line:
            CrashDesc = line.strip()
            if "leaked" in line and "allocation" in line:
                CrashType = "memory leaks"
                tupleLA = re.findall(r"\d+", line)
        elif "AddressSanitizer CHECK failed" in line:
            index = line.find('AddressSanitizer CHECK failed')
            tmp = line[index:].strip()
            CrashDesc = tmp.strip()
        elif "#" in line:
            tmplist = re.findall(r"\d+:\d+",line)
            if not tmplist == []:
                ll ,rr = tmplist[0].split(':',1)
        elif ("Assertion " in line and "failed" in line) or ("Assertion failure" in line):
            CrashType = "assertion failed"
            break
        if "Aborted (core dumped)" in line or "Aborted" in line or "SUMMARY: AddressSanitizer: " in line or "SUMMARY: ThreadSanitizer: " in line:
        #if "SUMMARY: AddressSanitizer: " in line:
            #print(CrashType, "---", CrashDesc)
            break
    if CrashType == '':
        CrashType = 'Exception'
    return CrashType, CrashDesc

# save the error message
def record_error_message(statusL, total_errors_interleavings, FILE_SAVED_MAXNUM, check_STDERR, check_STDOUT, process,
                         output_num, rlts, time, folder_name, stdoutdata, stderrdata, pattern, rounds):

    CrashType, CrashDesc = get_ASAN_error_type(stderrdata)

    lastFlag = 0
    if (not process.returncode in statusL):  # stderr
        statusL.append(process.returncode)
        lastFlag = 1

    if (process.returncode != 0 and process.returncode != 1 and process.returncode != 6 and process.returncode != -11):  # save result
        if total_errors_interleavings[0] < FILE_SAVED_MAXNUM:
            total_errors_interleavings[0] = total_errors_interleavings[0] + 1
            lastFlag = 1
            print("\033[31m\t[Error Found]: NO." + str(total_errors_interleavings[0]) + " " + CrashType + "\033[0m")
            err_file_name = (folder_name + "/" + "Errors" + "/" +
                             str(format(total_errors_interleavings[0], "0>6")) + "_" +
                             str(format(rounds, "0>7")) + "_" + CrashType.replace(' ', '-'))
            with open(err_file_name, "wb") as errfile:
                errfile.write(bytes(str(pattern) + "\n", encoding="utf8"))
                if check_STDERR == 1:
                    errfile.write(stderrdata)
            print("\033[31m\tThe interleavings saved in", err_file_name, "\033[0m")
    # elif (check_STDOUT > 1 and not stdoutdata in rlts):  # stdout
    elif (check_STDOUT > 1):  # stdout
        if output_num[0] < FILE_SAVED_MAXNUM:
            output_num[0] = output_num[0] + 1
            lastFlag = 1
            rlts.append(stdoutdata)
            print("\t", stdoutdata)
            out_file_name = folder_name + "/" + "DiffResult" + "/" + str(format(output_num[0], "0>6"))
            with open(out_file_name, "wb") as outfile:
                outfile.write(bytes(str(pattern) + "\n", encoding="utf8"))
                outfile.write(stdoutdata)

    if (lastFlag == 1):  # last Round
        lastRound = rounds
        lastTime = time.time()

def record_atomicity_violation(folder_name, ato, inter): # rxadd
    atomicity_violation_folder = os.path.join(folder_name, "Atomicity_Violations")
    if not os.path.exists(atomicity_violation_folder):
        os.makedirs(atomicity_violation_folder)

    atomicity_violation_file_name = os.path.join(atomicity_violation_folder,
                                                 str(format(len(os.listdir(atomicity_violation_folder)) + 1,
                                                            "0>6")) + ".txt")

    with open(atomicity_violation_file_name, "w", encoding="utf-8") as av_file:
        av_file.write("Atomicity Violation Detected:\n")
        av_file.write(f"Interleavings: {inter}\n")
        av_file.write("Violations:\n")
        for violation in ato:
            av_file.write(f"{violation}\n")

def record_all_atomicity_violation(folder_name, global_ato, exe_time, bug_depth, rounds, total_buggy_schedule,first_buggy_schedule): # rxadd
    all_atomicity_violation_folder = os.path.join(folder_name, "Atomicity_Violations")
    if not os.path.exists(all_atomicity_violation_folder):
        os.makedirs(all_atomicity_violation_folder)

    all_atomicity_violation_file_name = os.path.join(all_atomicity_violation_folder, "all_ato.txt")
    exe_time = formateTimeSeconds(exe_time)
    AV_num = len(global_ato)
    with open(all_atomicity_violation_file_name, "w", encoding="utf-8") as all_av_file:
        all_av_file.write(f"DynamicExecutionTime: {exe_time}\n")
        all_av_file.write(f"bug_depth: {bug_depth}\n")
        all_av_file.write(f"firstAVSched: {first_buggy_schedule}\n")
        all_av_file.write(f"AVSched: {total_buggy_schedule}\n")
        all_av_file.write(f"totalSched: {rounds}\n")
        all_av_file.write(f"AV num: {AV_num}\n")
        if AV_num:
            for idx, violation in enumerate(global_ato, start=1):
                all_av_file.write(f"({idx}) {violation}\n")
        else:
            all_av_file.write("No atomicity violations were found\n")

# save the timeout message
def record_timeout_message(total_timeouts_interleavings, FILE_SAVED_MAXNUM, subprocessTimeout,
                           check_STDERR, folder_name, pattern):
    if total_timeouts_interleavings[0] < FILE_SAVED_MAXNUM:
        total_timeouts_interleavings[0] = total_timeouts_interleavings[0] + 1
        print("\033[33m\t[Timeout " + str(subprocessTimeout) + "]: NO." + str(total_timeouts_interleavings[0]) + "\033[0m")
        timeout_file_name = folder_name + "/" + "Timeouts" + "/" + str(format(total_timeouts_interleavings[0], "0>6"))
        with open(timeout_file_name, "wb") as timeoutfile:
            timeoutfile.write(bytes(str(pattern) + "\n", encoding="utf8"))
            if check_STDERR == 1:
                timeoutfile.write(bytes("Timeout = " + str(subprocessTimeout), encoding="utf8"))
        print("\033[33m\tunder interleavings saved in", timeout_file_name, "\033[0m")
