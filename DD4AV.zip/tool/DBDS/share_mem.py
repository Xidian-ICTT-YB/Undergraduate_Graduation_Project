import subprocess
from record import *
from ipc import *


# This is the structrue of Share Memory class
SHARE_THREAD_NUM = 100
SHARE_ARRAY_SIZE = 3964
# typedef struct Sched_Info {
#	uint64_t time;								// the execution time of the program (nsec)
#	unsigned int N;								// number of threads concerned
#	unsigned int M;								// number of kep points per thread
#	unsigned int TestedPeriod;					// It took several period in testing engine
#	uint16_t kpNumArray[SHARE_THREAD_NUM];	    // the specific kpNum of each My_tid Thread, only consider almost 10 thread
#	uint16_t kp[SHARE_ARRAY_SIZE];			    // how many times should a thread yield before a kp
#	uint16_t kpLoc[SHARE_ARRAY_SIZE];		    // the hash ID of Key Point
#	uint16_t kpOrder[SHARE_ARRAY_SIZE];		    // recored the order of key points
#   uint16_t kpdynamicaddress[SHARE_ARRAY_SIZE];	// recorded the dynamic adress  kladd
# } sched_info;

def setup_share_memroy():
    IPC_KEY, MAP_SIZE, IPC_CREAT, IPC_EXCL = 1111, sizeof(c_ulonglong) + sizeof(c_uint) * 3 + sizeof(c_uint16) * (
            SHARE_THREAD_NUM + 4 * SHARE_ARRAY_SIZE), 512, 1024  # 修改到4*（原本3）
    shmget = cdll.LoadLibrary("libc.so.6").shmget
    shmat = cdll.LoadLibrary("libc.so.6").shmat
    shmat.restype = c_void_p
    shm_id = shmget(IPC_KEY, MAP_SIZE, IPC_CREAT | IPC_CREAT | 0o666)
    ADDR = shmat(shm_id, 0, 0)
    return ADDR

def get_info_from_share_memory(ADDR, P=None, A=None, B=None, T=None, kpNumArray=None,
                               kpYieldArray=None, kpLocArray=None, kpOrderArray=None, kpDArray=None, kpTimeArray=None):
    if P != None:
        memmove(byref(P), ADDR, sizeof(c_ulonglong))
    if A != None:
        memmove(byref(A), ADDR + sizeof(c_ulonglong), sizeof(c_uint))
    if B != None:
        memmove(byref(B), ADDR + sizeof(c_ulonglong) + sizeof(c_uint), sizeof(c_uint))
    if T != None:
        memmove(byref(T), ADDR + sizeof(c_ulonglong) + sizeof(c_uint) * 2, sizeof(c_uint))
    if kpNumArray != None:
        memmove(byref(kpNumArray), ADDR + sizeof(c_ulonglong) + sizeof(c_uint) * 3, sizeof(c_uint16) * SHARE_THREAD_NUM)
    if kpYieldArray != None:
        memmove(byref(kpYieldArray),
                ADDR + sizeof(c_ulonglong) + sizeof(c_uint) * 3 + sizeof(c_uint16) * (SHARE_THREAD_NUM),
                sizeof(c_uint16) * (SHARE_ARRAY_SIZE))
    if kpLocArray != None:
        memmove(byref(kpLocArray),
                ADDR + sizeof(c_ulonglong) + sizeof(c_uint) * 3 + sizeof(c_uint16) * (SHARE_THREAD_NUM + SHARE_ARRAY_SIZE),
                sizeof(c_uint16) * SHARE_ARRAY_SIZE)
    if kpOrderArray != None:
        memmove(byref(kpOrderArray),
                ADDR + sizeof(c_ulonglong) + sizeof(c_uint) * 3 + sizeof(c_uint16) * (SHARE_THREAD_NUM + 2 * SHARE_ARRAY_SIZE),
                sizeof(c_uint16) * SHARE_ARRAY_SIZE)
    # kl add
    if kpDArray != None:
        memmove(byref(kpDArray),
                ADDR + sizeof(c_ulonglong) + sizeof(c_uint) * 3 + sizeof(c_uint16) * (SHARE_THREAD_NUM + 3 * SHARE_ARRAY_SIZE),
                sizeof(c_uint16) * SHARE_ARRAY_SIZE)
    if kpTimeArray != None:
        memmove(byref(kpTimeArray),
                ADDR + sizeof(c_ulonglong) + sizeof(c_uint) * 3 + sizeof(c_uint16) * (SHARE_THREAD_NUM + 4 * SHARE_ARRAY_SIZE),
                sizeof(c_uint16) * SHARE_ARRAY_SIZE)

def memmove_pattern_list(ADDR,PatternList):
    tmp = []
    for t in PatternList:
        tmp += t
    tmparr = (c_uint16 * len(tmp))(*tmp)
    memmove(ADDR + sizeof(c_ulonglong) + sizeof(c_uint) * 3 + sizeof(c_uint16) * SHARE_THREAD_NUM,
            tmparr,
            sizeof(c_uint16) * len(tmp))

# create subprocess according to the value of check_STDOUT and check_STDERR
def create_DBDS_subprocess(DBDS_Command, check_STDOUT, check_STDERR):
    if (check_STDOUT >= 1 and check_STDERR == 1):
        process = subprocess.Popen(DBDS_Command, close_fds=True, preexec_fn=os.setpgrp, stdout=subprocess.PIPE,stderr=subprocess.PIPE)
    elif (check_STDOUT >= 1 and check_STDERR == 0):
        process = subprocess.Popen(DBDS_Command, close_fds=True, preexec_fn=os.setpgrp, stdout=subprocess.PIPE)
    elif (check_STDOUT == 0 and check_STDERR == 1):
        process = subprocess.Popen(DBDS_Command, close_fds=True, preexec_fn=os.setpgrp, stderr=subprocess.PIPE)
    else:
        process = subprocess.Popen(DBDS_Command, close_fds=True, preexec_fn=os.setpgrp)
    return process